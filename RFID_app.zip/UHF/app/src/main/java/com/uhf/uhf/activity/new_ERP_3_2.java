package com.uhf.uhf.activity;

import static com.uhf.uhf.activity.MainActivity.myIP;
import static com.uhf.uhf.activity.MainActivity.test1;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.uhf.uhf.R;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.Arrays;

public class new_ERP_3_2 extends new_ERP_2_A {

    String topic;
    private String msg;
    private TextView mbacktomain_2;

    public static WebView subText;
    public static ProgressBar mprogressbar_web_final;
    MqttAndroidClient client;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.last_web_view);
        final String trigger = "trigger";


        Intent intent = getIntent();
        final String actiontobedone = intent.getStringExtra("key");
        final String stockselected = intent.getStringExtra("key_1");

        if (test1 == null) {
            test1 = "NO ITEMS IS SCANNED";
        }

        // if its check missing do diff action

        subText = (WebView) findViewById (R.id.finalpagewebview);
        mprogressbar_web_final = (ProgressBar) findViewById (R.id.list_final_progress_2);
        mbacktomain_2 = (TextView) findViewById (R.id.backtomain_2);

        mprogressbar_web_final.setVisibility(View.VISIBLE);
        subText.setVisibility(View.INVISIBLE);


        String clientId = MqttClient.generateClientId();
        client = new MqttAndroidClient
                (this.getApplicationContext(), myIP, clientId);
        topic = "checkk";

        Singleton_3.getInstance(client, this.getApplicationContext());

        {
            try {
                IMqttToken token = client.connect();
                token.setActionCallback(new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        Log.e("page3_2", "connected");
                        setSubscription("page3_2");
                        try {
                            client.publish("check", test1.getBytes(), 0, false);
                            client.publish("openoption_check", stockselected.getBytes(), 0, false);
                        } catch (MqttException e) {
                            e.printStackTrace();
                        }

                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        Log.e("doisconnected", "disconnected");
                        Toast.makeText(new_ERP_3_2.this, "connection failed!!", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
        //refresh
        mbacktomain_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent().setClass(new_ERP_3_2.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void setSubscription(String topic){
        try{
            client.subscribe(topic,0);
            client.subscribe("totest",0);
            client.subscribe("duplicate", 0);
        }catch (MqttException e){
            e.printStackTrace();
        }
    }
}


