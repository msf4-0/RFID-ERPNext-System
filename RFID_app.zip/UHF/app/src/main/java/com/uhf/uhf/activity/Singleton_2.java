package com.uhf.uhf.activity;

import static com.uhf.uhf.activity.ListAdapterInitialiser.gah_2;
import static com.uhf.uhf.activity.ListAdapterInitialiser.gah_3;
import static com.uhf.uhf.activity.ListAdapterInitialiser.rah_2;
import static com.uhf.uhf.activity.ListAdapterInitialiser.rah_3;
import static com.uhf.uhf.activity.MainActivity.activity;
import static com.uhf.uhf.activity.MainActivity.myIP;
import static com.uhf.uhf.activity.MainActivity.test1;
import static com.uhf.uhf.activity.new_ERP_3.actiontobedone;

import static com.uhf.uhf.activity.new_ERP_3.mexitdialog;
import static com.uhf.uhf.activity.new_ERP_3.selectedstock;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.List;

public class Singleton_2 {
    private static Singleton_2 singleton_2;
    private static String msg_3;

    private Singleton_2() {}

    private static void PopulateList(String [] openlist)
    {
        Log.e("poadd","dsalgd");
        gah_3.clear();
        if (gah_3.size() != openlist.length + 1) {
            for (int i = 0; i < openlist.length; i++) {
                gah_3.add(openlist[i]);
            }
        }
        rah_3.notifyDataSetChanged();
        rah_2.notifyDataSetChanged();
    }

    private static void PopulateList_2(String [] openlist){
        Log.e("ads","ads");
        gah_2.clear();
        if (gah_2.size() != openlist.length + 1) {
            for (int i = 0; i < openlist.length; i++) {
                gah_2.add(openlist[i]);
            }
        }
        rah_2.notifyDataSetChanged();
        rah_3.notifyDataSetChanged();
    }


    public static Singleton_2 getInstance(final MqttAndroidClient theclientstatic,
                                          final Context context)
    {


        if (singleton_2 == null)
        {
            Log.e("alot","of times");
            singleton_2 = new Singleton_2();
            Setcallbackset(theclientstatic);
        }

        return singleton_2;
    }

    private static void IFAILED() {
        //set new call back
        String clientId = MqttClient.generateClientId();

        final MqttAndroidClient client = new MqttAndroidClient
                (activity.getApplicationContext(), myIP, clientId);

        IMqttToken token = null;
        {
            try {
                token = client.connect();
                Log.e("Singleton2connect", "to the client");

            } catch (MqttException e) {
                e.printStackTrace();
            }
        } //connect
        token.setActionCallback(new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Log.e("Singleton2page3", "connected");
                try {
                    client.subscribe("return", 0);
                    client.subscribe("totest",0);
                    client.subscribe("stockitems", 0);
                    client.subscribe("page3",0);
                    client.subscribe("page3next",0);
                    client.subscribe("actionfinished",0);
                    switch (actiontobedone)
                    {
                        case "check in": {
                            client.publish("checkinduplicate", test1.getBytes(), 0, false);
                            client.publish("openoption", selectedstock.getBytes(), 0, false);
                            break;
                        }
                        case "check out": {
                            client.publish("checkinmissing", test1.getBytes(), 0, false);
                            client.publish("openoption", selectedstock.getBytes(), 0, false);
                            break;
                        }
                    }
                    Log.e("Singlton2page3", "once");
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Log.e("Singleton2doisconnected", "disconnected");
            }
        });
        Setcallbackset(client);
    }

    private static void Setcallbackset(final MqttAndroidClient theclientstatic) {
        theclientstatic.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                IFAILED();
                Log.e("Singleton2conectionlsot","conecoitnolist");
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception
            {
                Log.e("Singleton2page3",topic);
                msg_3 = new String(message.getPayload());
                switch (topic) {
                    case "actionfinished": {
                        {
                            if (msg_3.equals("CHANGES MADE"))
                            {
                                new_ERP_3.mtextpopout.setText("CHANGES HAS BEEN MADE");
                                new_ERP_3.mtextpopout.setTextColor(Color.parseColor("#018524"));
                            } else if (msg_3.equals("all checked out")) {
                                new_ERP_3.mtextpopout.setText("CHANGES HAS BEEN MADE");
                                new_ERP_3.mtextpopout.setTextColor(Color.parseColor("#018524"));
                            }
                            else
                            {
                                //warning message
                                new_ERP_3.mtextpopout.setText(msg_3);
                                new_ERP_3.mtextpopout.setTextColor(Color.RED);
                            }
                        }

                        new_ERP_3.mtextpopout.setVisibility(View.VISIBLE);
                        new_ERP_3.mpopupprogresscircle.setVisibility(View.GONE);

                        switch (new_ERP_3.mainaction)
                        {
                            case "check in to": {
                                Log.e ("message has return"," checkfor duplicate");

                                theclientstatic.publish("checkinduplicate", gah_2.toString().getBytes(), 0, false);
                                theclientstatic.publish("openoption", new_ERP_3.selectedstock.getBytes(), 0, false);
                                break;
                            }
                            case "check out from": {
                                Log.e ("message has return"," checkfor missing");

                                theclientstatic.publish("checkinmissing", gah_2.toString().getBytes(), 0, false);
                                theclientstatic.publish("openoption", new_ERP_3.selectedstock.getBytes(), 0, false);
                                break;
                            }
                        }
                        break;
                    }

                    case "page3next": {
                        //populate the list for stock - next page - stock items
                        if (msg_3 != null) {
                            Log.e("Singelton2page3n",msg_3);
                            String test = msg_3;
                            test = test.replaceAll("[\\[\\]\\\"]", "");
                            String[] openlist = test.split(",");
                            PopulateList(openlist);
                        }
                        break;
                    }
                    case "page3": {
                        //split string into array then add to ArrayAdapter - first page - item scanned
                        if (msg_3 != null) {
                            Log.e("Singleton2pg3",msg_3);
                            String test = msg_3;
                            test = test.replaceAll("[\\[\\]\\\"]", "");
                            String[] openlist = test.split(",");
                            PopulateList_2(openlist);
                            new_ERP_3.mprogressfinal.setVisibility(View.GONE);
                            new_ERP_3.mmostofhtitems.setVisibility(View.VISIBLE);
                        }
                    }
                    break;
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });
    }

}
