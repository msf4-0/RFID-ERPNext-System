package com.uhf.uhf.activity;

import static android.text.TextUtils.isEmpty;

import static com.uhf.uhf.UHFApplication.getContext;
import static com.uhf.uhf.activity.MainActivity.myIP;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;



import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;


import android.widget.Switch;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.reader.helper.InventoryBuffer;
import com.reader.helper.ReaderHelper;
import com.uhf.uhf.R;
import com.uhf.uhf.activity.ERP;
import com.uhf.uhf.activity.MainActivity;
import com.uhf.uhf.activity.new_ERP_2_A;


import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeUnit;

public class new_ERP_1 extends BaseActivity {

    MqttAndroidClient client;
    private TextView one1, two2, and3;
    private String msg;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_selection);

        one1 = (TextView) findViewById(R.id.checkinbutton);
        two2 = (TextView) findViewById(R.id.checkoutbutton);
        and3 = (TextView) findViewById(R.id.checkbutton);

        //next page
        one1.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.e("ok","checkin");
                Intent intent;
                intent = new Intent().setClass(new_ERP_1.this, new_ERP_2_A.class);
                intent.putExtra("key", "check in to");
                startActivity(intent);
            }
        });
        two2.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.e("ok","checkout");
                Intent intent;
                intent = new Intent().setClass(new_ERP_1.this, new_ERP_2_A.class);
                intent.putExtra("key", "check out from");
                startActivity(intent);
            }
        });
        and3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.e("ok","checkmissing");
                Intent intent;
                intent = new Intent().setClass(new_ERP_1.this, new_ERP_2_A.class);
                intent.putExtra("key", "check for missing items");
                startActivity(intent);
            }
        });
    }

}
