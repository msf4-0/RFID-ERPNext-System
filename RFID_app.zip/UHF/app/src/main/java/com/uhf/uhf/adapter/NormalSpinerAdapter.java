package com.uhf.uhf.adapter;

import android.content.Context;

public class NormalSpinerAdapter extends AbstractSpinerAdapter<String>{

	public  NormalSpinerAdapter(Context context){
		super(context);
	}
}
