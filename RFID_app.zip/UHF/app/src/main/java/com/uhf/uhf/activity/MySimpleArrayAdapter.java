package com.uhf.uhf.activity;

import static com.uhf.uhf.activity.MainActivity.activity;
import static com.uhf.uhf.activity.MainActivity.dictionary;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.uhf.uhf.R;
import com.uhf.uhf.adapter.AbstractSpinerAdapter;

import java.util.ArrayList;

public class MySimpleArrayAdapter extends ArrayAdapter<String> {
    private final Context context;
    private final ArrayList<String> values;
    private String gottenitem;
    private String[] openlist;

    public MySimpleArrayAdapter(Context context, ArrayList<String> values) {
        super(context, -1, values);
        this.context = context;
        this.values = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.mycustomadapter, parent, false);

        TextView text_left = (TextView) rowView.findViewById(R.id.icon);
        TextView text_right = (TextView) rowView.findViewById(R.id.firstLine);


        Object[] objects = values.toArray();

        gottenitem = objects[position].toString();

        String value = dictionary.get(gottenitem.trim());

        text_left.setText(gottenitem);

        if (gottenitem == "") {
            //Log.e("3",gottenitem);
            text_left.setText("NO ITEMS IS SCANNED");
        } else if (gottenitem.contains("already in")) {
            openlist = gottenitem.split("split ");
            text_right.setText("already in stock");
            text_right.setTextColor(Color.parseColor("#fc5e03"));
            text_left.setText(openlist[0]);
        } else if (gottenitem.contains("not in stock")) {
            openlist = gottenitem.split("split ");
            text_right.setText("missing");
            text_right.setTextColor(Color.parseColor("#fc5e03"));
            text_left.setText(openlist[0]);
        } else if (gottenitem.contains("not an item")) {
            openlist = gottenitem.split("split ");
            text_right.setText("not an item");
            text_right.setTextColor(Color.RED);
            text_left.setText(openlist[0]);
        }

        if (value != null) {
            Log.e("mybasicfainl2",value);
                text_left.setText(value);
        }

        Object s = objects[position];
        return rowView;
    }
}
