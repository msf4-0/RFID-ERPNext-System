package com.uhf.uhf.activity;

import android.content.Context;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.uhf.uhf.R;

import java.util.ArrayList;
import java.util.Arrays;

public class StockListAdapter {


    private static StockListAdapter stocklistadapter;


    public static ArrayList<String> gah;
    public static ArrayAdapter<String> rah;
    public StockListAdapter() {
        Log.e("or","just noce");
    }



    //public static ArrayAdapter<String> getInstance()
    public static String getInstance(Context context) {

        String something = null;

            if (stocklistadapter == null) {
                stocklistadapter = new StockListAdapter();
                gah = new ArrayList<String>(Arrays.asList(""));
                rah = new ArrayAdapter<String>(context,R.layout.list_at_centre,gah);
                something = "first time";
            }
            else {
                something = "second time already";
            }

            return something;
    }




}
