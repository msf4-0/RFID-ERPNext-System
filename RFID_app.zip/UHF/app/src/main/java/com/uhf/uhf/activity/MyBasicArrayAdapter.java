package com.uhf.uhf.activity;

import static com.uhf.uhf.activity.MainActivity.dictionary;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.uhf.uhf.R;

import java.util.ArrayList;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.uhf.uhf.R;

import java.util.ArrayList;

public class MyBasicArrayAdapter extends ArrayAdapter<String> {
    private final Context context;
    private final ArrayList<String> values;
    private String gottenitem;
    private String[] openlist;

    public MyBasicArrayAdapter(Context context, ArrayList<String> values) {
        super(context, -1, values);
        this.context = context;
        this.values = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.list_at_centre_2, parent, false);
        TextView textetxt = (TextView) rowView.findViewById(R.id.basictext);
        Object[] objects = values.toArray();
        gottenitem = objects[position].toString();

        String value = dictionary.get(gottenitem.trim());

        if (value == null) {
            value =  "sad";
            Log.e("mybasicval",value);
            if (gottenitem != null) {
                value = gottenitem;
                Log.e("mybasicfinval1",value);
            }
        }
        if (value != null) {
            textetxt.setText(value);
        }

        Object s = objects[position];

        return rowView;
    }
}
