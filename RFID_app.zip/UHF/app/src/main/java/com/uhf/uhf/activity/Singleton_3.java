package com.uhf.uhf.activity;

import static com.uhf.uhf.activity.ListAdapterInitialiser.gah_2;
import static com.uhf.uhf.activity.MainActivity.activity;
import static com.uhf.uhf.activity.MainActivity.myIP;
import static com.uhf.uhf.activity.MainActivity.test1;
import static com.uhf.uhf.activity.new_ERP_3.selectedstock;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.uhf.uhf.R;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.Arrays;

public class Singleton_3 {

    private static Singleton_3 singleton_3;
    private static String msg_3;

    public Singleton_3() {}


    public static Singleton_3 getInstance(MqttAndroidClient theclientstatic,
                                        Context context)
    {
        if (singleton_3 == null)
        {

            Log.e("alot","of times");
            singleton_3 = new Singleton_3();
            Setcallbackset(theclientstatic);
        }

        return singleton_3;
    }



    private static void IFAILED()
    {
        String clientId = MqttClient.generateClientId();

        final MqttAndroidClient client = new MqttAndroidClient
                (activity.getApplicationContext(), myIP, clientId);
        IMqttToken token = null;
        {
            try {
                token = client.connect();
                Log.e("singleton3connect", "to the client");

            } catch (MqttException e) {
                e.printStackTrace();
            }
        } //connect
        token.setActionCallback(new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Log.e("Singelton3", "connected");
                try {
                    client.subscribe("page3_2",0);
                    client.subscribe("totest",0);
                    client.subscribe("duplicate", 0);
                    if (test1 == null) {test1= "no items is scanned";};
                    client.publish("check", test1.getBytes(), 0, false);
                    client.publish("openoption_check", selectedstock.getBytes(), 0, false);
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Log.e("singleton3doisconnected", "disconnected");
            }
        });
        Setcallbackset(client);
    }

    private static void Setcallbackset(final MqttAndroidClient theclientstatic)
    {
        theclientstatic.setCallback(new MqttCallback() {

            @Override
            public void connectionLost(Throwable cause) {
                IFAILED();
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                msg_3 = new String(message.getPayload());
                new_ERP_3_2.subText.loadDataWithBaseURL(null, msg_3, "text/html", "utf-8", null);
                new_ERP_3_2.mprogressbar_web_final.setVisibility(View.GONE);
                new_ERP_3_2.subText.setVisibility(View.VISIBLE);
            }


            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });
    }



}
