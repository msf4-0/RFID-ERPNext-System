package com.uhf.uhf.activity;

import android.content.Context;
import android.util.Log;
import android.widget.ArrayAdapter;

import com.uhf.uhf.R;

import java.util.ArrayList;
import java.util.Arrays;

public class ListAdapterInitialiser {


    private static ListAdapterInitialiser listAdapterInitialiser;


    public static ArrayList<String> gah,gah_2,gah_3,gah_4;
    public static ArrayAdapter<String> rah,rah_2,rah_3,rah_4;
    public ListAdapterInitialiser() {}

    public static void getInstance(Context context) {

        if (listAdapterInitialiser == null) {
            listAdapterInitialiser = new ListAdapterInitialiser();
            gah = new ArrayList<String>(Arrays.asList(""));
            rah = new ArrayAdapter<String>(context,R.layout.list_at_centre,gah);

            gah_2 = new ArrayList<String>(Arrays.asList(""));
            gah_3 = new ArrayList<String>(Arrays.asList(""));

            rah_2 = new MySimpleArrayAdapter(context,gah_3);
            rah_3 = new MySimpleAA2(context,gah_2);

        }
    }
}
