package com.uhf.uhf.activity;

import java.util.HashMap;
import java.util.Map;

public class Totest {
    public static void main(String args[]) {
        String msg_2 = "[{\"1\",\"abc\":\"2\",\"def\":\"3\",\"ghi\"}]";
        Map<String, String> map = new HashMap<String, String>();
        map.put("dog", "type of animal");
        System.out.println(map.get("dog"));
        String[] splitedlist_2 = null;
        if (msg_2!=null) {
            String spliter = msg_2;
            spliter = spliter.replaceAll("[{}]", "");
            System.out.println((spliter));
            spliter = spliter.replaceAll("\"","");
            System.out.println(spliter);
            spliter = spliter.replaceAll("\\[", "").replaceAll("\\]","");
            System.out.println((spliter));
            String[] splitedlist = spliter.split(",");

            int kk = splitedlist.length;
            System.out.println(String.valueOf(kk));
            for (int i = 0; i < splitedlist.length; i ++) {
                System.out.println(String.valueOf(i));
                System.out.println(splitedlist[i]);
                System.out.println(splitedlist[i+1]);
                //dictionary.put(" "+splitedlist_2[i],splitedlist_2[i+1]);
            }

        }
    }
}

