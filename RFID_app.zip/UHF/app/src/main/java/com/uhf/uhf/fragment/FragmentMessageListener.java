package com.uhf.uhf.fragment;

public interface FragmentMessageListener {
    void sendMessage(String message);
}
