package com.uhf.uhf.activity;

import static com.uhf.uhf.activity.MainActivity.activity;
import static com.uhf.uhf.activity.MainActivity.myIP;
import static com.uhf.uhf.activity.new_ERP_2_A.shortAnimationDuration;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.uhf.uhf.R;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.Arrays;

public class Singleton {

    //the reason i used singleton
    //is because i did not know static
    // stores data
    // and I can just use if null
    // to check if data is empty or not
    private static Singleton singleton;
    private static String msg_2;


    public Singleton() {}

    private static void PopulateList(String[] openlist)
    {
        ListAdapterInitialiser.gah.clear();
        if (ListAdapterInitialiser.gah.size() != openlist.length + 1) {
            for (int i = 0; i < openlist.length; i++) {
                ListAdapterInitialiser.gah.add(openlist[i]);
            }
        }
        ListAdapterInitialiser.rah.notifyDataSetChanged();
        // i made a singleton but realise the list is only updated once
        // this is due to having no experience in JAVA OR OOP
        // do not code in JAVA because KOTLIN OR FLUTTER is available
        // pupulate list is to BYPASS the final


    }

    public static Singleton getInstance(final MqttAndroidClient theclientstatic,
                                        final ProgressBar progressBarstatic,
                                        final ListView itemsstatic,
                                        final Context context)
    {
        if (singleton == null)
        {
            singleton = new Singleton();
            Setcallbackset(theclientstatic);
        }
        return singleton;
    }

    private static void Setcallbackset(MqttAndroidClient theclientstatic) {

        theclientstatic.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                IFAILED();
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception
            {
                Log.e("page2", topic);
                switch (topic) {
                    case "totest":
                    case "return": {
                        msg_2 = new String(message.getPayload());
                        Log.e("return", msg_2);
                        //split string into array then add to ArrayAdapter
                        if (msg_2 != null) {
                            String test = msg_2;
                            test = test.replaceAll("[\\[\\]\\\"]", "");
                            String[] openlist = test.split(",");
                            PopulateList(openlist);
                            crossfade();
                        }
                        break;
                    }
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });

    }

    private static void IFAILED() {
        Log.e("singelton","failure");
        String clientId = MqttClient.generateClientId();

        final MqttAndroidClient client = new MqttAndroidClient
                (activity.getApplicationContext(), myIP, clientId);

        IMqttToken token = null;
        {
            try {
                token = client.connect();
                Log.e("Singletonconnect", "to the client");

            } catch (MqttException e) {
                e.printStackTrace();
            }
        } //connect
        token.setActionCallback(new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Log.e("Singletonpage2", "connected");
                try {
                    client.subscribe("return", 0);
                    client.publish("button", "seomthing".getBytes(), 0, false);
                    Log.e("Singletonpage2", "once");
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Log.e("Singletondoisconnected", "disconnected");
            }
        });
        Setcallbackset(client);

    }

    private static void crossfade() {

        new_ERP_2_A.items.setVisibility(View.VISIBLE);
        new_ERP_2_A.items.setAlpha(0f);
        new_ERP_2_A.items.animate()
                .alpha(1f)
                .setDuration(shortAnimationDuration)
                .setListener(null);
        new_ERP_2_A.progressbar.animate()
                    .alpha(0f)
                .setDuration(shortAnimationDuration)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        new_ERP_2_A.progressbar.setVisibility(View.GONE);
                    }
                });

    }





}
