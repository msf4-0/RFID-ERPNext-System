package com.uhf.uhf.activity;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;

import com.uhf.uhf.R;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.Arrays;

public class Connection {

    private       static Connection          connInst;
    private       static boolean             connected;

    private       static MqttAndroidClient mqttAndroidClient;
    private       static IMqttActionListener mqttActionListener;
    private final static MqttConnectOptions mqttConnectOptions = new MqttConnectOptions ();




    private Connection (Context context) {
        //Instantiate the mqtt android client class
        String secondId = MqttClient.generateClientId();
        mqttAndroidClient = new MqttAndroidClient (context.getApplicationContext (), "tcp://192.168.0.29:1883", secondId);
        Setcallback();

        mqttActionListener = new IMqttActionListener () {

            @Override
            public void onSuccess (IMqttToken asyncActionToken) {
                System.out.println ("BROKER CONNECTED");
                try {
                    mqttAndroidClient.subscribe("return",0);
                } catch (MqttException e) {
                    e.printStackTrace();
                }

                //mqttAndroidClient.setBufferOpts (disconnectedBufferOptions);

            }

            @Override
            public void onFailure (IMqttToken asyncActionToken, Throwable exception) {
                System.out.println ("Failed to connect to: ");
            }
        };
    }

    public static Connection getInstance (Context context) {
        if (connInst == null) {
            connInst = new Connection (context);
        }
        createConnectionIfNeeded ();

        return connInst;
    }

    public static void Setcallback(

    ) {


        mqttAndroidClient.setCallback (new MqttCallback() {

            @Override
            public void connectionLost (Throwable cause) {
                connected = false;
                System.out.println ("The Connection was lost.");
            }

            @Override
            public void messageArrived (String topic, final MqttMessage message) throws Exception {
                System.out.println ("Message received and Arrived");
                Log.e("i am ","infinite");
                String msg_2 = new String(message.getPayload());
                Log.e("return", msg_2);
                //Log.e("fordisplay",fordisplay.toString());
            }

            @Override
            public void deliveryComplete (IMqttDeliveryToken token) {
                System.out.println("Message Delivered");
            }
        });

    }

    private static void createConnectionIfNeeded () {
        if (connected) {
            return;
        }
        try {
            mqttAndroidClient.connect (mqttConnectOptions, null, mqttActionListener);
            Log.e("Maybe","no infinute");
        } catch (MqttException ex) {
            ex.printStackTrace ();
        }
    }

    // ...
}
