package com.uhf.uhf.activity;

import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.media.Image;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import static android.text.TextUtils.isEmpty;

import static com.uhf.uhf.UHFApplication.getContext;
import static com.uhf.uhf.activity.ListAdapterInitialiser.gah_2;
import static com.uhf.uhf.activity.ListAdapterInitialiser.gah_3;
import static com.uhf.uhf.activity.ListAdapterInitialiser.rah_3;
import static com.uhf.uhf.activity.MainActivity.activity;
import static com.uhf.uhf.activity.MainActivity.myIP;
import static com.uhf.uhf.activity.MainActivity.test1;

import android.app.AlertDialog;
import android.app.Dialog;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;



import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;


import android.widget.Switch;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.ViewSwitcher;

import com.reader.helper.InventoryBuffer;
import com.reader.helper.ReaderHelper;
import com.uhf.uhf.R;
import com.uhf.uhf.activity.ERP;
import com.uhf.uhf.activity.MainActivity;


import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeUnit;

import com.uhf.uhf.R;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.w3c.dom.Text;

public class new_ERP_3 extends new_ERP_2_A {

    private ListView items_2,items_stock;
    private String thisitem, msg;
    private TextView mtitletext_3,  page1, page2, mdeleteselections,mselectitems,mbacktomain;
    private ImageView mleftic, mrightic;
    private TextView mbutton_3;
    private Dialog dialogforitem;
    private LinearLayout myfirstview, mysecondview;
    private ViewSwitcher mviewswitchpage3;

    private static ArrayList<String> selections;
    private static Integer hold;

    public static String mainaction,selectedstock,actiontobedone;
    public static TextView mtextpopout, mexitdialog;

    public static LinearLayout mmostofhtitems;
    public static ProgressBar mprogressfinal,mpopupprogresscircle;

    String topic;
    MqttAndroidClient client;

    private LinearLayout.LayoutParams layoutParamsbig = new LinearLayout.LayoutParams(50, 50);
    private LinearLayout.LayoutParams layoutParamssmol = new LinearLayout.LayoutParams(30, 30);

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.last_list_view);
        final String trigger = "trigger";

        Intent intent = getIntent();
        actiontobedone = intent.getStringExtra("key");
        switch (actiontobedone)
        {
            case "check in to": {
                actiontobedone = "check in";
                break;
            }
            case "check out from": {
                actiontobedone ="check out";
                break;
            }
        }
        final String stockselected = intent.getStringExtra("key_1");
        selectedstock = stockselected;

        mprogressfinal = (ProgressBar) findViewById (R.id.list_final_progress);
        mtitletext_3 = (TextView) findViewById(R.id.textView_3_1);
        mbutton_3 = (TextView) findViewById (R.id.button_3);
        mmostofhtitems = (LinearLayout) findViewById(R.id.mostoftheitems);
        mdeleteselections = (TextView) findViewById (R.id.rubbishbin);
        mselectitems = (TextView) findViewById (R.id.selectselect_page3);
        mbacktomain = (TextView) findViewById (R.id.backtomain);

        mviewswitchpage3 = (ViewSwitcher) findViewById(R.id.viewSwitcher1);
        myfirstview = (LinearLayout) findViewById (R.id.View1);
        mysecondview = (LinearLayout) findViewById (R.id.View2);

        page1 = (TextView) findViewById (R.id.pg1_B);
        page2 = (TextView) findViewById (R.id.pg2_B);
        mrightic = (ImageView) findViewById (R.id.rightERP3);
        mleftic = (ImageView) findViewById (R.id.leftERP3);

        //popup
        dialogforitem = new Dialog(new_ERP_3.this);
        dialogforitem.setContentView(R.layout.itemdetailpopout);
        mpopupprogresscircle = dialogforitem.findViewById(R.id.progress_bar_popup);
        mtextpopout = dialogforitem.findViewById(R.id.popuptext);
        mexitdialog = dialogforitem.findViewById(R.id.exitdialog);

        mtitletext_3.setText(stockselected);
        mbutton_3.setText(actiontobedone+" ALL items");

        final ArrayList<String> gList_2 = ListAdapterInitialiser.gah_2;
        final ArrayAdapter<String> gAdapter_2 = ListAdapterInitialiser.rah_3;
        ArrayList<String> gList_3 = gah_3;
        final ArrayAdapter<String> gAdapter_3 = ListAdapterInitialiser.rah_2;
        gah_2.clear();
        gah_3.clear();

        selections = new ArrayList<String>(Arrays.asList("1"));
        selections.clear();

        items_stock = (ListView) findViewById(R.id.listView_3_next);
        items_stock.setAdapter(gAdapter_3);

        items_2 = (ListView) findViewById(R.id.listView_3);
        items_2.setAdapter(gAdapter_2);
        //items_2.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        //show progress bar onCreate
        mprogressfinal.setVisibility((View.VISIBLE));
        mmostofhtitems.setVisibility(View.INVISIBLE);
        mdeleteselections.setVisibility(View.GONE);
        mbutton_3.setEnabled(true);

        show = false;
        //show afect SimpleAA2 , from ArrayAdapter, to show checkbox or not

        Log.e("page3newerp3","created");

        //test1 is scanned items
        String test = test1;
        if (test1 == "[]") {
            Log.e("newerp3[]","itemscaned");
            disableButton();
        }
        else if (test1 == null) {
            Log.e("newerp3null","null");
            disableButton();
        } else if (test1 == "NO ITEMS IS SCANNED") {
            Log.e("newerp3notitems","null");
            disableButton();
        }

        {
            Log.e("newper3populate",test1);
            if (test!= null) {
            test = test.replaceAll("[\\[\\]\\\"]", "");
            String[] openlist = test.split(",");
            gList_2.clear();
            if (gList_2.size() != openlist.length + 1) {
                for (int i = 0; i < openlist.length; i++) {
                    gList_2.add(openlist[i]);
                }
            }
            gAdapter_2.notifyDataSetChanged();}
            else {}//if test1 is null do nothing
        }


        String clientId = MqttClient.generateClientId();
        client = new MqttAndroidClient
                (this.getApplicationContext(), myIP, clientId);
        topic = "checkk";

        Singleton_2.getInstance(client, this.getApplicationContext());
        //Singleton is to set the actions to be done when a message is received.

        {
            try {
                IMqttToken token = client.connect();
                Log.e("newERP3","onnet");
                token.setActionCallback(new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        try {
                            // if connected get the latest list
                            setSubscription("return");
                            Log.e("nweerpe3page3", "connected");
                            switch (actiontobedone)
                            {
                                case "check in": {
                                    setSubscription("return");
                                    client.publish("checkinduplicate", test1.toString().getBytes(), 0, false);
                                    client.publish("openoption", stockselected.getBytes(), 0, false);
                                    break;
                                }
                                case "check out": {
                                    setSubscription("return");
                                    client.publish("checkinmissing", test1.toString().getBytes(), 0, false);
                                    client.publish("openoption", stockselected.getBytes(), 0, false);
                                    break;
                                }
                            }
                        }catch (MqttException e){
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        Log.e("newerp3doisconnected", "disconnected");
                        Toast.makeText(new_ERP_3.this, "connection failed!!", Toast.LENGTH_LONG).show();
                    }
                });
            } catch (MqttException e) {
                e.printStackTrace();
            }
        } //connect

        token.getActionCallback();

        page1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                changePagetoLeft();
            }
        });
        page2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                changePagetoRight();
            }
        });

        mrightic.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                changePagetoRight();
            }
        });
        mleftic.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                changePagetoLeft();
            }
        });


        mmostofhtitems.setOnTouchListener(new OnSwipeTouchListener(new_ERP_3.this) {
            public void onSwipeRight() {
                changePagetoLeft();
                /**
                 else if(mviewswitchpage3.getCurrentView()!=mysecondview)
                 {
                 mviewswitchpage3.showNext();
                 page2.setBackgroundResource(R.drawable.bg_circle_hollow_grey);
                 }
                 **/
            }
            public void onSwipeLeft() {
                /**
                 if (mviewswitchpage3.getCurrentView() != myfirstview) {
                 mviewswitchpage3.showPrevious();
                 page1.setBackgroundResource(R.drawable.bg_circle_hollow);

                 }
                 **/
                changePagetoRight();
            }
        }); //swipe listener action

        mexitdialog.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogforitem.dismiss();
            }
        });

        mselectitems.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //switch between selection mode by controlling hold
                if (hold == null) {
                    mselectitems.setText("X");
                    for (int i = selections.size()-1; i >= 0; i--) {
                        items_2.setItemChecked(i,false);
                    }
                    show = true;
                    rah_3.notifyDataSetChanged();
                    selections.clear();
                    items_2.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                    Log.e("1pr","es");
                    hold = 1;
                    mbutton_3.setText(actiontobedone + " SELECTED items");
                }
                else if (hold != null) {

                    mselectitems.setText("SELECT");
                    for (int i = selections.size()-1; i >= 0; i--) {
                        items_2.setItemChecked(i,false);
                    }
                    // is not good ^^^^
                    // when unchecking it should uncheck item index at selection (i)
                    // should items_2.setItemChecked(position, false)
                    // where posistion is selection(i)
                    selections.clear();
                    items_2.setChoiceMode(ListView.CHOICE_MODE_NONE);
                    Log.e("2pr","es");
                    show = false;
                    rah_3.notifyDataSetChanged();
                    mdeleteselections.setVisibility(View.GONE);
                    hold = null;
                    mbutton_3.setText(actiontobedone + "ALL items");
                }
            }
        });

        items_2.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Log.e("do","tgn");
                thisitem = items_2.getItemAtPosition(position).toString();
                if (hold == null) {
                    //update mode
                    AlertDialog.Builder alert = new AlertDialog.Builder(mbutton_3.getContext()); //some code online for pop up boz + update
                    alert.setTitle("Confirm");
                    String[] splilist = new String[0];
                    if (thisitem.contains("split")) {
                        splilist = thisitem.split("split ");
                    } else {splilist[0] = thisitem;}
                    alert.setMessage("Are you sure you want to "+actiontobedone+" "+splilist[0]+"?");
                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    try {
                                        setSubscription("return");
                                        //dialogforitem.show();
                                        switch (actiontobedone) {
                                            case "check in":
                                            {
                                                setSubscription("return");
                                                client.publish("naightmear", thisitem.getBytes(), 0, false);
                                                break;
                                            }
                                            case "check out":
                                            {
                                                setSubscription("return");
                                                client.publish("update", thisitem.getBytes(), 0, false);
                                                break;
                                            }

                                        }

                                        changePagetoRight();
                                    } catch (MqttException e) {
                                        e.printStackTrace();
                                    }
                                    dialogforitem.show();
                                    mpopupprogresscircle.setVisibility(View.VISIBLE);
                                    mtextpopout.setVisibility(View.GONE);

                                }
                            }
                    );
                    alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alert.show();
                }
                if (hold != null) {
                    //selection mode
                    Log.e("newper3o", thisitem);
                    mdeleteselections.setVisibility(View.VISIBLE);
                    if (!selections.contains(thisitem)) {
                        selections.add(thisitem);
                        items_2.setItemChecked(position, true);
                    } else if (selections.contains(thisitem)) {
                        Log.e("newerp3remove", String.valueOf(position));
                        selections.remove(selections.indexOf(thisitem));
                        items_2.setItemChecked(position, false);
                        if (selections.isEmpty()) {
                            mdeleteselections.setVisibility(View.GONE);
                        }
                    }
                }
            }
        });

        /**
        items_2.setOnItemLongClickListener(new OnItemLongClickListener() {


            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                //gList_2.remove(position);
                //gAdapter_2.notifyDataSetChanged();
                //delete
                return true;
            }
        });
**/

        mdeleteselections.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                {
                    //delete selected items

                    AlertDialog.Builder alert = new AlertDialog.Builder(mbutton_3.getContext()); //some code online for pop up boz + update
                    alert.setTitle("Confirm");
                    alert.setMessage("Are you sure you want to "+"delete" +" ?");
                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Log.e("newerp3deete","dete");
                                    for (int i = selections.size()-1; i >= 0; i--) {
                                        Log.e("newerp3i", String.valueOf(i));
                                        Log.e("newerp3gList", String.valueOf(selections.get(i)));
                                        String iteminlist = selections.get(i);
                                        gList_2.remove(gList_2.indexOf(iteminlist));
                                        items_2.setItemChecked(i,false);
                                    }
                                    //unselect items
                                    selections.clear();
                                    if (gList_2.isEmpty()){
                                        //if all item is removed
                                        gList_2.add("all items removed!");
                                        mbutton_3.setEnabled(false);
                                        mbutton_3.setTextColor(Color.RED);
                                        mbutton_3.setText("no items scanned");
                                        mselectitems.setVisibility(View.INVISIBLE);
                                        items_2.setEnabled(false);
                                    }
                                    gAdapter_2.notifyDataSetChanged();
                                    mdeleteselections.setVisibility(View.INVISIBLE);
                                    mselectitems.setText("SELECT");
                                    items_2.setChoiceMode(ListView.CHOICE_MODE_NONE);
                                    show = false;
                                    rah_3.notifyDataSetChanged();
                                    mdeleteselections.setVisibility(View.GONE);
                                    hold = null;
                                    //exit selection mode
                                }
                            }
                    );
                    alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alert.show();
                }
            }
        });

        mbacktomain.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent().setClass(new_ERP_3.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        mbutton_3.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                {
                    //update the stock (checkin checkout)
                    //selection mode - hold
                    if (hold == null) {
                        //do this
                        AlertDialog.Builder alert = new AlertDialog.Builder(mbutton_3.getContext()); //some code online for pop up boz + update
                        alert.setTitle("Confirm");
                        alert.setMessage("Are you sure you want to "+ actiontobedone+ "ALL items?");
                        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        try {
                                            setSubscription("return");
                                            // action ALL items
                                            switch (actiontobedone) {
                                                case "check in":
                                                {
                                                    setSubscription("return");
                                                    client.publish("naightmear", gList_2.toString().getBytes(), 0, false);
                                                    break;
                                                }
                                                case "check out":
                                                {
                                                    setSubscription("return");
                                                    client.publish("update", gList_2.toString().getBytes(), 0, false);
                                                    break;
                                                }
                                            }

                                        } catch (MqttException e) {
                                            e.printStackTrace();
                                        }
                                        changePagetoRight();
                                        dialogforitem.show();
                                        mpopupprogresscircle.setVisibility(View.VISIBLE);
                                        mtextpopout.setVisibility(View.GONE);
                                    }
                                }
                        );
                        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        alert.show();
                    }
                    if (hold != null) {
                        AlertDialog.Builder alert = new AlertDialog.Builder(mbutton_3.getContext()); //some code online for pop up boz + update
                        alert.setTitle("Confirm");
                        alert.setMessage("Are you sure you want to "+actiontobedone+" SELECTED items?");
                        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        try {
                                            //action selected items
                                            setSubscription("return");
                                            switch (actiontobedone) {
                                                case "check in":
                                                {
                                                    setSubscription("return");
                                                    client.publish("naightmear", selections.toString().getBytes(), 0, false);
                                                    break;
                                                }
                                                case "check out":
                                                {
                                                    setSubscription("return");
                                                    client.publish("update", selections.toString().getBytes(), 0, false);
                                                    break;
                                                }
                                            }
                                            changePagetoRight();
                                            mselectitems.setText("SELECT");
                                            for (int i = selections.size()-1; i >= 0; i--) {
                                                items_2.setItemChecked(i,false);
                                            }
                                            selections.clear();
                                            items_2.setChoiceMode(ListView.CHOICE_MODE_NONE);
                                            Log.e("2pr","es");
                                            show = false;
                                            rah_3.notifyDataSetChanged();
                                            mdeleteselections.setVisibility(View.GONE);
                                            hold = null;
                                            mbutton_3.setText(actiontobedone+" ALL items");
                                            //quit selections mode
                                        } catch (MqttException e) {
                                            e.printStackTrace();
                                        }
                                        dialogforitem.show();
                                        mpopupprogresscircle.setVisibility(View.VISIBLE);
                                        mtextpopout.setVisibility(View.GONE);
                                    }
                                }
                        );
                        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        alert.show();
                    }

                }
            }
        });

    }

    private void setSubscription(String topic){
        try{
            client.subscribe(topic,0);
            client.subscribe("totest",0);
            client.subscribe("stockitems", 0);
            client.subscribe("page3",0);
            client.subscribe("page3next",0);
            client.subscribe("actionfinished",0);
        }catch (MqttException e){
            e.printStackTrace();
        }

    }

    private void changePagetoLeft() {
        if(mviewswitchpage3.getCurrentView()!=myfirstview)
        {
            mviewswitchpage3.setInAnimation(AnimationUtils.loadAnimation(new_ERP_3.this, R.anim.my_slide_in_left));
            mviewswitchpage3.showPrevious();
            page1.setBackgroundResource(R.drawable.bg_circle_hollow);
            page2.setBackgroundResource(R.drawable.bg_circle_hollow_grey);
            page1.setLayoutParams(layoutParamsbig);
            page2.setLayoutParams(layoutParamssmol);
            mrightic.setVisibility(View.VISIBLE);
            mleftic.setVisibility(View.INVISIBLE);
        }
    }

    private void changePagetoRight() {
        if(mviewswitchpage3.getCurrentView()!=mysecondview)
        {
            mviewswitchpage3.setInAnimation(AnimationUtils.loadAnimation(new_ERP_3.this, R.anim.my_slide_in_right));
            mviewswitchpage3.showNext();
            page2.setBackgroundResource(R.drawable.bg_circle_hollow);
            page1.setBackgroundResource(R.drawable.bg_circle_hollow_grey);
            page1.setLayoutParams(layoutParamssmol);
            page2.setLayoutParams(layoutParamsbig);
            mrightic.setVisibility(View.INVISIBLE);
            mleftic.setVisibility(View.VISIBLE);
        }
    }

    private void disableButton() {
        test1 = "NO ITEMS IS SCANNED";
        mbutton_3.setEnabled(false);
        mbutton_3.setTextColor(Color.RED);
        mselectitems.setVisibility(View.INVISIBLE);
        mbutton_3.setText("no items scanned");
        items_2.setEnabled(false);
    }





}
