package com.uhf.uhf.activity;

import static android.text.TextUtils.isEmpty;

import static com.uhf.uhf.activity.MainActivity.myIP;

import android.app.AlertDialog;
import android.app.Dialog;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;



import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;


import android.widget.Switch;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.reader.helper.InventoryBuffer;
import com.reader.helper.ReaderHelper;
import com.uhf.uhf.R;
import com.uhf.uhf.activity.ERP;
import com.uhf.uhf.activity.MainActivity;
import com.uhf.uhf.activity.new_ERP_1;


import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeUnit;

public class new_ERP_2_A extends new_ERP_1 {

    public static ListView items;
    private String thisitem;
    private TextView mtitletext;
    public static ProgressBar progressbar;

    public static int shortAnimationDuration;


    public static boolean show;
    String topic;

    private MqttAndroidClient client;
    IMqttToken token;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.for_display_list_after);
        final String trigger = "trigger";

        Intent intent = getIntent();
        final String actiontobedone = intent.getStringExtra("key");

        show = false;

        mtitletext = (TextView) findViewById (R.id.titletext_2);
        progressbar = (ProgressBar) findViewById (R.id.list_after_progress);

        ArrayList<String> fordisplay = new ArrayList<String>(Arrays.asList("1"));

        ListAdapterInitialiser.getInstance(this.getApplicationContext());
        //initialise the adapter once

        ArrayList<String> globalslist = ListAdapterInitialiser.gah;
        ArrayAdapter<String> globalaadapater = ListAdapterInitialiser.rah;

        //itemadapteradapter.notifyDataSetChanged();
        items = (ListView) findViewById(R.id.listView_2);
        items.setAdapter(globalaadapater);

        ListAdapterInitialiser.rah.notifyDataSetChanged();

        mtitletext.setText("select stock to " + actiontobedone);

        //show progress bar onCreate
        progressbar.setVisibility(View.VISIBLE);
        items.setVisibility(View.INVISIBLE);

        String clientId = MqttClient.generateClientId();
            client = new MqttAndroidClient
                    (this.getApplicationContext(), myIP, clientId);
            {
                try {
                    token = client.connect();
                    Log.e ("NE_2connect","to the client");
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            } //connect
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Log.e("page2", "connected");
                    try {
                        //get latest stock list
                        client.subscribe("return",0);
                        client.publish("button", trigger.getBytes(), 0, false);
                        Log.e("page2","once");
                    }catch (MqttException e){
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Log.e("doisconnected", "disconnected");
                    Toast.makeText(new_ERP_2_A.this, "connection failed!!", Toast.LENGTH_LONG).show();
                }
            });

        topic = "checkk";

        Singleton.getInstance(client,progressbar,items,this.getApplicationContext());
        //action to be carried out when a message is received

        items.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Log.e("ok","is list pressed?");
                thisitem = items.getItemAtPosition(position).toString();
                Log.e("NEWE2obiosucly",thisitem);
                if (thisitem.equals("CREATE STOCK")) {
                    // if this item is create stock
                    try {
                        client.publish("newstock", "anything".getBytes(), 0, false);
                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }
                    else {
                    // go next page
                    {
                        switch (actiontobedone) {
                            case "check out from":
                            case "check in to": {
                                Intent intent;
                                intent = new Intent().setClass(new_ERP_2_A.this, new_ERP_3.class);
                                intent.putExtra("key", actiontobedone);
                                intent.putExtra("key_1", thisitem);
                                startActivity(intent);
                                break;
                            }
                            // if its check missing go diff page
                            case "check for missing items": {
                                Intent intent;
                                intent = new Intent().setClass(new_ERP_2_A.this, new_ERP_3_2.class);
                                intent.putExtra("key", actiontobedone);
                                intent.putExtra("key_1", thisitem);
                                startActivity(intent);
                                break;
                            }
                        }
                    }
                }
            }
        });
    }

    private void setSubscription(String topic){
        try{
            client.subscribe(topic,0);
            client.subscribe("totest",0);
            client.subscribe("duplicate", 0);
        }catch (MqttException e){
            e.printStackTrace();
        }
    }

}