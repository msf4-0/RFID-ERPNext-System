package com.uhf.uhf.activity;

import static android.text.TextUtils.isEmpty;

import android.app.AlertDialog;
import android.app.Dialog;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;



import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Spinner;


import android.widget.Switch;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.reader.helper.InventoryBuffer;
import com.reader.helper.ReaderHelper;
import com.uhf.uhf.R;


import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeUnit;

public class backedup_ERP_puthere extends MainActivity{

    MqttAndroidClient client;
    WebView subText, subText2;
    EditText mess;
    String topic, cat, msg, diffmsg,diffmsg1, diffmsg2, thisitem, textat, essay;
    Integer j, k, l, m ,g, w, x, c;
    List test;
    Spinner server;
    Dialog dialogforitem;
    private TextView itemsbutton,singlecheck, openingstock,refreshbutton;
    private TextView checkout, newstock, mtiteletext;
    private ProgressBar mprogressbar4;
    private ToggleButton mtoggle;
    private ListView items, startitems;
    private Button overwritestock, addmissingitem;
    MyTask asyncTask;


    private static  ReaderHelper mReaderHelper;

    private static InventoryBuffer m_curInventoryBuffer;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.erp);
        final String trigger = "trigger";

        //itemsbutton = (TextView) findViewById(R.id.pubButton);
        singlecheck = (TextView) findViewById(R.id.checkButton);
        openingstock = (TextView) findViewById(R.id.pubButton2);
        refreshbutton = (TextView) findViewById(R.id.refreshbutton);
        checkout = (TextView) findViewById(R.id.pubButton3);
        //newstock = (TextView) findViewById(R.id.pubButton5);
        mprogressbar4 = (ProgressBar) findViewById(R.id.horiindifine);
        mprogressbar4.setIndeterminate(true);
        mprogressbar4.setVisibility(View.GONE);
        mtoggle = (ToggleButton) findViewById(R.id.toggleButton2);
        mtiteletext = (TextView) findViewById (R.id.textView2);


        singlecheck.setEnabled(false);
        openingstock.setEnabled(false);
        checkout.setEnabled(false);
        //itemsbutton.setEnabled(false);


        subText = (WebView) findViewById(R.id.subText);
        //subText2 = (WebView) findViewById (R.id.subText2);




        server = (Spinner) findViewById(R.id.topic);
        final ArrayList<String> category = new ArrayList<String>();
        category.add("<placeholder>");
        final ArrayAdapter<String> itemsAdapter2
                = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,category);
        itemsAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);//added test to the end
        server.setAdapter(itemsAdapter2);

        final ArrayList<String> fordisplay =
                new ArrayList<String>
                        (Arrays.asList("111,222,333,444,555,666".split(",")));
        fordisplay.clear();
        final ArrayAdapter<String> itemsAdapter =
                //  new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, fordisplay);
                new ArrayAdapter<String>(this,R.layout.list_at_centre, fordisplay);

        items = (ListView) findViewById(R.id.listView1);
        items.setAdapter(itemsAdapter);

        startitems = (ListView) findViewById(R.id.listView2);
        startitems.setAdapter(itemsAdapter);



        dialogforitem = new Dialog(backedup_ERP_puthere.this);
        dialogforitem.setContentView(R.layout.itemdetailpopout);
        //subText2 = dialogforitem.findViewById(R.id.subText2);
        //subText2.getSettings().setLoadWithOverviewMode(true);
        //subText2.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);

        //subText2.getSettings().setUseWideViewPort(true);
        //overwritestock = (Button) dialogforitem.findViewById (R.id.overrrite);
        //addmissingitem = (Button ) dialogforitem.findViewById (R.id.naightmare);

        subText.setVisibility(View.VISIBLE);
        items.setVisibility(View.GONE);
        startitems.setVisibility(View.GONE);
        addmissingitem.setVisibility(View.GONE);
        overwritestock.setVisibility(View.GONE);

        k = 0 ; l = 0 ; m = 0 ; g = 0 ; w = 0 ; x = 0 ; c = 0;

        String clientId = MqttClient.generateClientId();
        client = new MqttAndroidClient
                (this.getApplicationContext(), "tcp://192.168.0.22:1883", clientId);
        //changeIPhere<clientId
        topic = "checkk";


        //this is box after whatever you do.
        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

                Log.e("conectionlsot","conecoitnolist");

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.e("GGONE",topic);
                switch (topic)
                {
                    case "totest":
                    {
                        diffmsg1 = new String(message.getPayload());
                        Log.e("action", diffmsg1);
                        if (diffmsg1.equals("crashtheapp"))
                        {
                            Log.e("whynot",diffmsg1);
                            stopTheTask();
                        }//stop the loading bar so other things can be done // also stop the erpnext manually if necaseyf
                        break;
                    }
                    case "return":
                    {
                        if (w == 1) {
                            items.setVisibility(View.VISIBLE);
                            subText.setVisibility(View.GONE);
                        } //hide web view
                        else if (w == 2) {
                            subText.setVisibility(View.VISIBLE);
                            items.setVisibility(View.GONE);
                        } //show webview

                        msg = new String(message.getPayload());
                        subText.loadDataWithBaseURL(null, msg, "text/html", "utf-8", null);
                        subText2.loadDataWithBaseURL(null, msg, "text/html", "utf-8", null);

                        Log.e("j,k,w", j.toString() + " " + k.toString() + " " + w.toString());

                        if (j == 1) {
                            if (msg != null) {
                                String test = msg;
                                test = test.replaceAll("[\\[\\]\\\"]", "");
                                String[] openlist = test.split(",");
                                category.clear();
                                category.add("");
                                if (category.size() != openlist.length + 1) {
                                    for (int i = 0; i < openlist.length; i++) {
                                        category.add(openlist[i]);
                                    }
                                }
                                itemsAdapter2.notifyDataSetChanged();
                            }
                            g = 0;
                            mtiteletext.setText("stock list");
                        } // add to spinner

                        if (k == 1) {
                            if (msg != null) {

                                String test = msg;
                                test = test.replaceAll("[\\[\\]\\\"]", "");
                                String[] openlist = test.split(",");
                                fordisplay.clear();

                                if (fordisplay.size() != openlist.length + 1) {
                                    for (int i = 0; i < openlist.length; i++) {
                                        fordisplay.add(openlist[i]);
                                    }
                                }
                                itemsAdapter.notifyDataSetChanged();
                            }
                        } // add to list

                        if (m == 3) {
                            dialogforitem.show();
                            m = 0;
                        } // show pop up

                        else if (m == 4) {
                            dialogforitem.show();
                            m = 0;
                        } //show pop up

                        // done
                        //as
                        break;
                    }
                    case "duplicate":
                    {

                        addmissingitem.setVisibility(View.VISIBLE);
                        overwritestock.setVisibility(View.VISIBLE);
                        msg = new String(message.getPayload());
                        mtiteletext.setText("thesearetheduplicateitems");
                        essay = ("hi there is some duplicate items here," +
                                "would you like to check in anyways and overwrite the stock\n" +
                                ", or would you like to check in new items only \n" +
                                " or would you like to remove the duplicate items and scan again \n" +
                                " ? For the duplicate items please refer to the list shown or you can check which item is missing \n" +
                                ". Thank you");

                        if (w == 1) {
                            items.setVisibility(View.VISIBLE);
                            subText.setVisibility(View.GONE);
                        } //hide web view
                        else if (w == 2) {
                            subText.setVisibility(View.VISIBLE);
                            items.setVisibility(View.GONE);
                        } //show webview

                        // show 2 buttons
                        l = 1;
                        k = 1;
                        x = 1;

                        subText2.loadData(essay, "text/html; charset=utf-8", "utf-8");

                        //set to essay
                        if (m == 3) {
                            dialogforitem.show();
                        } // show pop up

                        else if (m == 4) {
                            dialogforitem.show();
                        } //show pop up

                        if (k == 1) {
                            if (msg != null) {

                                String test = msg;
                                test = test.replaceAll("[\\[\\]\\\"]", "");
                                String[] openlist = test.split(",");
                                fordisplay.clear();

                                if (fordisplay.size() != openlist.length + 1) {
                                    for (int i = 0; i < openlist.length; i++) {
                                        fordisplay.add(openlist[i]);
                                    }
                                }
                                itemsAdapter.notifyDataSetChanged();
                            }
                        } // add to list

                        break;
                    }
                }
                j = 0;
                k = 0;
                x = 0;
                Log.e("wherej0", j.toString());
                Log.e("wherek0", k.toString());
                stopTheTask();
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });

        //this is whatever is displayed in the BOX when u first start up the, namely the scanned items
        {
            if (test1 == "[]") {
                test1 = "NO ITEMS IS SCANNED";

            } // imported is empty android/paho chose
            else {
                if (test1 != null) {
                    mtiteletext.setText("scanned items");
                    subText.setVisibility(View.GONE);
                    items.setVisibility(View.GONE);
                    startitems.setVisibility(View.VISIBLE);
                    String test = test1;
                    test = test.replaceAll("[\\[\\]\\\"]", "");
                    String[] openlist = test.split(",");
                    fordisplay.clear();
                    if (fordisplay.size() != openlist.length + 1) {
                        for (int i = 0; i < openlist.length; i++) {
                            fordisplay.add(openlist[i]);
                        }
                    }
                    itemsAdapter.notifyDataSetChanged();
                }
                singlecheck.setEnabled(true);
                checkout.setEnabled(true);
                openingstock.setEnabled(true);
                //itemsbutton.setEnabled(true);

            }
        }


        checkcons();

        //check connection
        // all function should be disabled if failed

        //for not connected loop
        // for connected break
        //here lies new reconnect button
        // I have one its the toggle lmao
        //make it appear out of thin air
        //then disappear
        // which does checkcons again


        startitems.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {}
        });

        items.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                thisitem = items.getItemAtPosition(position).toString();
                cat = thisitem;
                if (g == 0){textat = cat;} //set tile text
                Log.e("o",thisitem);
                if ((thisitem.equals("CREATE STOCK"))) {
                    try {
                        //setSubscription();
                        client.publish("newstock", "namingseries".getBytes(), 0, false);

                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }
                else if (l == 0) {
                    Log.e("l is -","0");
                    j = 0;
                    k = 1;
                    {
                        if (asyncTask != null && asyncTask.getStatus() == AsyncTask.Status.RUNNING) {

                        } else {

                            try {
                                mtiteletext.setText("items inside " + thisitem);
                                startTheTask("K");
                                setSubscription("return");
                                client.publish("openoption", thisitem.getBytes(), 0, false);
                                //Toast.makeText(ERP.this, cat, Toast.LENGTH_SHORT).show();
                            } catch (MqttException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    l = 1;
                    m = 0;
                    //Toast.makeText(ERP.this, thisitem, Toast.LENGTH_SHORT).show();
                } //titelset stock
                else if (l == 1) {
                    Log.e("l is","1");
                    addmissingitem.setVisibility(View.GONE);
                    overwritestock.setVisibility(View.GONE);
                    //pop out here
                    if (asyncTask != null && asyncTask.getStatus() == AsyncTask.Status.RUNNING) {

                    } else {
                        try {
                            //subText.setVisibility(View.VISIBLE);
                            //items.setVisibility(View.INVISIBLE);
                            startTheTask("K");
                            setSubscription("return");
                            client.publish("itemdetail", thisitem.getBytes(), 0, false);
                            //Toast.makeText(ERP.this, cat, Toast.LENGTH_SHORT).show();
                        } catch (MqttException e) {
                            e.printStackTrace();
                        }
                        m = 4;
                    }

                    //subText2.loadDataWithBaseURL(null, msg, "text/html", "utf-8", null);


                    //Toast.makeText(ERP.this, thisitem, Toast.LENGTH_SHORT).show();
                    // new intent
                }  // get item detail
                //Toast.makeText(parent.getContext"OnItemSelectedListener : " + parent.getItemAtPosition(position).toString,Toast.LENGTH_SHORT).show();
                //Toast.makeText(ERP.this, thisitem, Toast.LENGTH_SHORT).show();

            }
        });


        //Spinner spinner = (Spinner) findViewById(R.id.topic);
        server.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected (AdapterView < ? > parent, View view, int pos, long id) {

                cat = server.getItemAtPosition(pos).toString();
                thisitem = cat;
                Log.e("awlays", cat);
                k = 1;
                if (cat != "<placeholder>" ) {

                    //TransitionManager.beginDelayedTransition(transitionsContainer);
                    items.setVisibility(View.VISIBLE);
                    subText.setVisibility(View.GONE);
                }
                Log.e ("k", k.toString());
                if (thisitem.equals("CREATE STOCK")) {
                    try {
                        //setSubscription();
                        client.publish("newstock", "namingseries".getBytes(), 0, false);

                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }
                else if ( thisitem == "") {Log.e("i set","to 0");}
                else if (asyncTask != null && asyncTask.getStatus() == AsyncTask.Status.RUNNING) {

                } else {
                    if (cat != "<placeholder>" )
                    {
                        mtiteletext.setText("items inside " + thisitem);
                        l = 1;
                    }
                    try {
                        //j = 1;
                        //startTheTask("K");
                        setSubscription("return");
                        client.publish("openoption", cat.getBytes(), 0, false);
                        //Toast.makeText(ERP.this, cat, Toast.LENGTH_SHORT).show();
                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }
                j = 0;
                m = 0;
                server.setSelection(0);
                //}
            }
            public void onNothingSelected (AdapterView < ? > parent){
                // Another interface callback
            }
        });

        refreshbutton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                mtiteletext.setText("");
                w = 1;
                //startitems.setVisibility(View.INVISIBLE);
                if (asyncTask != null && asyncTask.getStatus() == AsyncTask.Status.RUNNING) {

                }
                else
                {
                    startTheTask("K");
                    try {
                        j = 1;
                        k = 1;
                        l = 0;
                        m = 0;
                        setSubscription("return");
                        client.publish("button", trigger.getBytes(), 0, false);
                        //add the fetch items as array

                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }

            }
        });

        refreshbutton.setOnLongClickListener(new View.OnLongClickListener() {

            @Override
            public boolean onLongClick(View v) {
                try {
                    addmissingitem.setVisibility(View.GONE);
                    overwritestock.setVisibility(View.GONE);
                    //setSubscription();
                    client.publish("newstock", "namingseries".getBytes(), 0, false);

                } catch (MqttException e) {
                    e.printStackTrace();
                }
                return true;
            }
        });

        singlecheck.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (asyncTask != null && asyncTask.getStatus() == AsyncTask.Status.RUNNING) {

                }
                else {
                    try {
                        w = 2;
                        Log.e("pass","here");
                        startTheTask("K");
                        setSubscription("return");
                        client.publish("check", test1.getBytes(), 0, false);

                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        singlecheck.setOnLongClickListener(new View.OnLongClickListener() {

            @Override
            public boolean onLongClick(View v) {
                try {
                    //setSubscription();
                    client.publish("item", test1.getBytes(), 0, false);

                } catch (MqttException e) {
                    e.printStackTrace();
                }
                return true;
            }
        });

        openingstock.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                if (asyncTask != null && asyncTask.getStatus() == AsyncTask.Status.RUNNING) {

                } else {
                    AlertDialog.Builder alert = new AlertDialog.Builder(checkout.getContext()); //some code online for pop up boz + update
                    alert.setTitle("Confirm");
                    alert.setMessage("Are you sure you want to check in these items to "+ textat +" ?");
                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    startitems.setVisibility(View.GONE);
                                    startTheTask("K");
                                    //updatestock.setEnabled(false);
                                    String trigger = "trigger";
                                    try {
                                        w = 1;
                                        l = 0;
                                        g = 1;
                                        m = 4;

                                        setSubscription("return");
                                        //setSubscription("open");
                                        client.publish("addtoitem", test1.getBytes(), 0, false);
                                        //Toast.makeText(ERP.this, "List uploading", Toast.LENGTH_SHORT).show();
                                    } catch (MqttException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                    );
                    alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alert.show();
                }
            }
        });

        checkout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                addmissingitem.setVisibility(View.GONE);
                overwritestock.setVisibility(View.GONE);
                if (asyncTask != null && asyncTask.getStatus() == AsyncTask.Status.RUNNING) {


                } else {
                    AlertDialog.Builder alert = new AlertDialog.Builder(checkout.getContext()); //some code online for pop up boz + update
                    alert.setTitle("Confirm");
                    alert.setMessage("Are you sure you want to check out these items from " +textat + "?");
                    alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    startitems.setVisibility(View.GONE);

                                    w = 1;
                                    l = 1;
                                    g = 1;
                                    m = 4;
                                    startTheTask("K");
                                    //updatestock.setEnabled(false);
                                    String trigger = "trigger";
                                    try {
                                        setSubscription("return");
                                        client.publish("update", test1.getBytes(), 0, false);
                                        //Toast.makeText(ERP.this, "checking out, please wait..", Toast.LENGTH_SHORT).show();
                                    } catch (MqttException e) {
                                        e.printStackTrace();
                                    }
                                }

                            }
                    );
                    alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    alert.show();
                }
            }
        });


        overwritestock.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                addmissingitem.setVisibility(View.GONE);
                overwritestock.setVisibility(View.GONE);
                dialogforitem.dismiss();
                try {
                    //setSubscription();
                    client.publish("overaite", test1.getBytes(), 0, false);
                    //Toast.makeText(ERP.this, "new stock", Toast.LENGTH_SHORT).show();
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }
        });

        addmissingitem.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                addmissingitem.setVisibility(View.GONE);
                overwritestock.setVisibility(View.GONE);
                dialogforitem.dismiss();
                try {
                    //setSubscription();
                    client.publish("naightmear", test1.getBytes(), 0, false);
                    //Toast.makeText(ERP.this, "new stock", Toast.LENGTH_SHORT).show();
                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }
        });




    }

    private void setSubscription(String topic){
        try{
            client.subscribe(topic,0);
            client.subscribe("totest",0);
            client.subscribe("duplicate", 0);
        }catch (MqttException e){
            e.printStackTrace();
        }
    }

    private void startTheTask(String notmsg) {

        startitems.setVisibility(View.GONE);

        if (asyncTask == null || asyncTask.getStatus() == AsyncTask.Status.FINISHED ) {
            asyncTask = new MyTask();
            asyncTask.execute("my string parameter");
        }
        else if (asyncTask.getStatus() == AsyncTask.Status.PENDING  || asyncTask == null) {
            //String halaap = asyncTask.getStatus().toString();
            //Toast.makeText(ERP.this, halaap, Toast.LENGTH_SHORT).show();
            asyncTask.execute("my string parameter");
        }
        else {
            String halaap = asyncTask.getStatus().toString();
            //Toast.makeText(ERP.this, halaap, Toast.LENGTH_SHORT).show(); //should be RUNNING

            final String s = "please wait";
        }
    }

    private void stopTheTask() {
        asyncTask.cancel(true);
        asyncTask = new MyTask();
    }

    private class MyTask extends AsyncTask<String, Integer, String> {
        // Runs in UI before background thread is called
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mprogressbar4.setVisibility(View.VISIBLE);
            // Do something like display a progress bar
        }
        // This is run in a background thread
        @Override
        protected String doInBackground(String... params) {
            // get the string from params, which is an array
            String myString = params[0];
            // Do something that takes a long time, for example:
            for (int i = 0; i <= 300; i++) {

                try {
                    Thread.sleep(80);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (isCancelled())
                {
                    //do this
                    break;
                }
                //if (i == 99) i = 0; to make infinite
                publishProgress(i);
            }
            return "this string is passed to onPostExecute";
        }
        // This is called from background thread but runs in UI
        @Override
        protected void onProgressUpdate(Integer... i) {
            super.onProgressUpdate(i);
            //Log.e("hi", String.valueOf(i));
            // Do things like update the progress bar
        }
        // This runs in UI when background thread finishes
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.e("finshed","finiwhed");
            mprogressbar4.setVisibility(View.GONE);

            // Do things like hide the progress bar or change a TextView
        }
        @Override
        protected void onCancelled() {
            Log.e("cancel","canceld");
            super.onCancelled();
            mprogressbar4.setVisibility(View.GONE);
        }
    }

    private void checkcons() {
        try {
            //startTheTask("ohnyo");
            IMqttToken token = client.connect();
            token.setActionCallback(new IMqttActionListener() {

                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    //IM CONNECTED!
                    //stopTheTask();
                    Log.e("connected","connected");
                    mtoggle.setChecked(true);
                    mtoggle.setTextColor(Color.GREEN);
                    String tag = "<html><body>"+test1+"</body></html>";
                    subText.loadData(tag, "text/html; charset=utf-8", "utf-8");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {

                    Log.e("doisconnected","disconnected");
                    //startTheTask("ohnyo");


                    // if failed stop them from doing anything
                    // and offer them to RC
                    // due to 2 reason WRONG IP and MQTT not inistliaseed
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

}
