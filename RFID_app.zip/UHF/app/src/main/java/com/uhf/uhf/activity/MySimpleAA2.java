package com.uhf.uhf.activity;

import static com.uhf.uhf.activity.MainActivity.activity;
import static com.uhf.uhf.activity.MainActivity.dictionary;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.uhf.uhf.R;
import com.uhf.uhf.adapter.AbstractSpinerAdapter;

import java.util.ArrayList;

public class MySimpleAA2 extends ArrayAdapter<String> {
    private final Context context;
    private final ArrayList<String> values;
    private String gottenitem;
    private String[] openlist;

    public MySimpleAA2(Context context, ArrayList<String> values) {
        super(context, -1, values);
        this.context = context;
        this.values = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.mycusadapter2_withcricle, parent, false);

        TextView text_left = (TextView) rowView.findViewById(R.id.icon);
        TextView text_right = (TextView) rowView.findViewById(R.id.firstLine);
        TextView tick = (TextView) rowView.findViewById(R.id.tick);
        TextView circle = (TextView) rowView.findViewById(R.id.circle);

        boolean shown = new_ERP_3.show;
        //show checkbox or not, for selection mode
        if (shown) {
            tick.setVisibility(View.VISIBLE);
            circle.setVisibility(View.VISIBLE);
        } else {tick.setVisibility(View.GONE);
        circle.setVisibility(View.GONE);}

        Object[] objects = values.toArray();

        gottenitem = objects[position].toString();

        text_left.setText(gottenitem);

        if (gottenitem == "") {
            //Log.e("3",gottenitem);
            text_left.setText("NO ITEMS IS SCANNED");
        } else if (gottenitem.contains("already in")) {
            openlist = gottenitem.split("split ");
            text_right.setText("already in stock");
            text_right.setTextColor(Color.parseColor("#fc5e03"));
            text_left.setText(openlist[0]);
            gottenitem = openlist[0];
        } else if (gottenitem.contains("not in stock")) {
            openlist = gottenitem.split("split ");
            text_right.setText("missing");
            text_right.setTextColor(Color.parseColor("#fc5e03"));
            text_left.setText(openlist[0]);
            gottenitem = openlist[0];
        } else if (gottenitem.contains("not an item")) {
            openlist = gottenitem.split("split ");
            text_right.setText("not an item");
            text_right.setTextColor(Color.RED);
            text_left.setText(openlist[0]);
            gottenitem = openlist[0];
        }


        String value = dictionary.get(gottenitem.trim());

        //check dictionrary if contain item
        // if yes replace with another name value
        if (value != null) {
            Log.e("mybasicfainlAA2",value);
            text_left.setText(value);
        }

        Object s = objects[position];
        return rowView;
    }
}
