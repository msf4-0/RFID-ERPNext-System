package com.uhf.uhf.activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.Toast;
import android.view.View.OnClickListener;
import android.widget.AdapterView.OnItemSelectedListener;

import com.uhf.uhf.R;
import android.text.Html;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class ERPList extends MainActivity {

    MqttAndroidClient client;
    MqttMessage message;
    WebView subText;
    Spinner server, itemserver , mess;
    String topic, msg,cat,open,theitemselected, colour, size;
    private TextView getlist,getcheckbox, edititem, additem, mrefresh,mrefreshi, mcreate, mdelete;
    EditText color1 , size1;
    Spinner dropd,dropdopening;
    Integer j;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_input_edit);

        edititem = (TextView) findViewById(R.id.button2);
        additem = (TextView) findViewById (R.id.button4);
        color1 = (EditText) findViewById (R.id.editText);
        size1 = (EditText) findViewById (R.id.editText2);
        mrefresh = (TextView) findViewById (R.id.button8);
        mrefreshi = (TextView) findViewById (R.id.button6);
        mcreate = (TextView) findViewById (R.id.button3);
        mdelete = (TextView) findViewById (R.id.button);

        server = (Spinner) findViewById(R.id.topicoflist);
        final ArrayList<String> category1 = new ArrayList<String>();
        category1.add("<placeholder>");
        final ArrayAdapter<String> itemsAdapter3
                = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, category1);
        itemsAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);//added test to the end
        server.setAdapter(itemsAdapter3);

         //sotkcpinser


            itemserver = (Spinner) findViewById(R.id.topicoflist3);
            final ArrayList<String> itemcategory = new ArrayList<String>();
            itemcategory.add("<placeholder>");
            final ArrayAdapter<String> itemsAdapter
                    = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, itemcategory);
            itemsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);//added test to the end
            itemserver.setAdapter(itemsAdapter);
         //item spinner

        String clientId = MqttClient.generateClientId();

        final String SMM = "tcp://192.168.0.22:1883"; //SHRDC MAXIS-MSF
        //final String SRM = ""// SHRDC RFID
        client = new MqttAndroidClient(this.getApplicationContext(), myIP, clientId); //changeIPhere<clientId
        topic = "checkk";

        try {
            IMqttToken token = client.connect();

            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Toast.makeText(ERPList.this, "connected!!", Toast.LENGTH_LONG).show();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Toast.makeText(ERPList.this, "connection failed!!", Toast.LENGTH_LONG).show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                Log.e("reply","t");
                msg = new String(message.getPayload());

                Log.e("reply",msg);

                if ( j == 1 ) {
                    if (msg != null) {
                        String test = msg;
                        test = test.replaceAll("[\\[\\]\\\"]", "");
                        String[] openlist = test.split(",");
                        category1.clear();
                        category1.add("");
                        if (category1.size() != openlist.length + 1) {
                            for (int i = 0; i < openlist.length; i++) {
                                category1.add(openlist[i]);
                            }
                        }
                        itemsAdapter3.notifyDataSetChanged();

                    }
                } // add to spinner
                if ( j == 2 ) {
                    if (msg != null) {
                        String test = msg;
                        test = test.replaceAll("[\\[\\]\\\"]", "");
                        String[] openlist = test.split(",");
                        itemcategory.clear();
                        itemcategory.add("");
                        if (itemcategory.size() != openlist.length + 1) {
                            for (int i = 0; i < openlist.length; i++) {
                                itemcategory.add(openlist[i]);
                            }
                        }
                        itemsAdapter.notifyDataSetChanged();
                    }
                } // add to spinner2
                j = 0;
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });

        server.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected (AdapterView < ? > parent, View view, int pos, long id) {

                cat = server.getItemAtPosition(pos).toString();

                //}
            }
            public void onNothingSelected (AdapterView < ? > parent){
                // Another interface callback
            }
        });

        itemserver.setOnItemSelectedListener(new OnItemSelectedListener() {

            @Override
            public void onItemSelected (AdapterView < ? > parent, View view, int pos, long id) {

                theitemselected = itemserver.getItemAtPosition(pos).toString();

            }
            public void onNothingSelected (AdapterView < ? > parent){
                // Another interface callback
            }
        });

        mrefresh.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                try {
                    setSubscription("return");
                    j = 1;
                    client.publish("button", "naming_series".getBytes(), 0, false);

                } catch (MqttException e) {
                    e.printStackTrace();
                }

            }
        });

        mrefreshi.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                try {
                    setSubscription("return");
                    j = 2;
                    client.publish("itemlu", "naming_series".getBytes(), 0, false);

                } catch (MqttException e) {
                    e.printStackTrace();
                }

            }
        });

        mcreate.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                try {
                    setSubscription("return");
                    client.publish("newstock", "naming_series".getBytes(), 0, false);

                } catch (MqttException e) {
                    e.printStackTrace();
                }

            }
        });

        mdelete.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                try {
                    setSubscription("return");

                    client.publish("deletestock", cat.getBytes(), 0, false);

                } catch (MqttException e) {
                    e.printStackTrace();
                }

            }
        });

        additem.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                    try {
                        //text = resources.getText(textRes)
                        colour = (color1.getText()).toString();
                        size = (size1.getText()).toString();
                        setSubscription("return");
                        client.publish("new_item_detail", (colour+", "+size).getBytes(), 0, false);
                        client.publish("item_create", test1.getBytes(), 0, false);
                        //add the fetch items as array

                    } catch (MqttException e) {
                        e.printStackTrace();
                    }
            }
        });

        edititem.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                try {
                    colour = String.valueOf(color1.getText());
                    size = String.valueOf(size1.getText());

                    setSubscription("return");
                    client.publish("item_detail", (colour+", "+size).getBytes(), 0, false);
                    client.publish("item_edit", theitemselected.getBytes(), 0, false);
                    //add the fetch items as array

                } catch (MqttException e) {
                    e.printStackTrace();
                }
            }
        });


    }

    private void setSubscription(String topic) {

        try {


            client.subscribe(topic, 0);
            client.subscribe("return",0);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}

