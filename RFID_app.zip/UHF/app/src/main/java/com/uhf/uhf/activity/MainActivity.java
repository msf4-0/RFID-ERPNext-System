package com.uhf.uhf.activity;



import static com.uhf.uhf.activity.new_ERP_3.actiontobedone;
import static com.uhf.uhf.activity.new_ERP_3.selectedstock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.uhf.uhf.widget.PopupMenu;
import com.uhf.uhf.R;
import com.uhf.uhf.UHFApplication;
import com.util.BeeperUtils;
import com.util.ExcelUtils;
import com.nativec.tools.ModuleManager;
import com.reader.base.ERROR;
import com.reader.base.ReaderBase;
import com.reader.helper.ISO180006BOperateTagBuffer;
import com.reader.helper.InventoryBuffer;
import com.reader.helper.OperateTagBuffer;
import com.reader.helper.ReaderHelper;
import com.reader.helper.ReaderSetting;
import com.uhf.uhf.widget.PopupMenu.MENUITEM;
import com.uhf.uhf.widget.PopupMenu.OnItemClickListener;
import com.uhf.uhf.dialog.CustomedDialog;
import com.uhf.uhf.widget.tagpage.PageInventoryReal;
import com.uhf.uhf.widget.tagpage.PageInventoryReal6B;
import com.uhf.uhf.widget.tagpage.PageTag6BAccess;
import com.uhf.uhf.widget.tagpage.PageTagAccess;

import com.util.PreferenceUtil;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class MainActivity extends BaseActivity {
    private ViewPager mPager;
    private List<View> listViews;
    private TextView title[] = new TextView[2];
    private int currIndex = 0;

    private TextView mRefreshButton;
    private TextView mSend;

    private ReaderBase mReader;
    private ReaderHelper mReaderHelper;

    private boolean mKeyF4Pressing = false;

    //test
    public static Activity activity;

    public static boolean mIsMonitorOpen = false;

    private static ReaderSetting m_curReaderSetting;
    private static InventoryBuffer m_curInventoryBuffer;
    private static OperateTagBuffer m_curOperateTagBuffer;
    private static ISO180006BOperateTagBuffer m_curOperateTagISO18000Buffer;

    public static int mSaveType = 0;

    private ImageView iv_menu;
    private PopupMenu popupMenu;

    private LocalBroadcastManager lbm;

    private MENUITEM cur_item = MENUITEM.ITEM1;
    public static final String REGION_TYPE = "region_type";
    public static final String FREQUENCY_INTERVAL = "frequency_interval";
    public static final String START_FREQUENCY = "start_frequency";

    MqttAndroidClient client;
    IMqttToken token;

    public int[] count;
    public static String test1;

    public static ArrayList<String> fordisplay_page1;
    public static ArrayAdapter<String> tobepopulater_page1;

    public static Map<String, String> dictionary = new HashMap<String, String>();

    public static String myIP;

    private ListView tobedisplayed_firstpage_list;
    private Button next;
    private LinearLayout linearmain;
    private TextView Logo1,Logo2,mcount;

    @Override
    protected void onResume() {
        if (mReader != null) {
            if (!mReader.IsAlive())
                mReader.StartWait();
        }
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //new
        String clientId = MqttClient.generateClientId();

        myIP = "tcp://192.168.0.31";
        client = new MqttAndroidClient(this.getApplicationContext(), myIP, clientId);
        {
            try {
                token = client.connect();
                Log.e ("MAINAconnect","to the client");

            } catch (MqttException e) {
                e.printStackTrace();
            }
        } //conncet

        token.setActionCallback(new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Log.e("MAINpage2", "connected");
                try {
                    //get latest list
                    client.subscribe("first_page",0);
                    client.publish("itemlist", "anyythig".getBytes(), 0, false);
                }catch (MqttException e){
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Log.e("MAINdoisconnected", "disconnected");
            }
        });

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                Log.e("MAINAplz","RC");
                IFAILED();
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception
            {
                // on reply add the list to dictionary
                // so it can be compared
                // in the ArrayAdapter
                dictionary.clear();
                Log.e("mainactivy", topic);
                String msg_2 = new String(message.getPayload()) ;
                Log.e("mainacityvy1st page", (msg_2));
                if (msg_2 != null) {
                    String spliter = msg_2;
                    spliter = spliter.replaceAll("[{}]", "");
                    spliter = spliter.replaceAll("\"", "");System.out.println(spliter);
                    spliter = spliter.replaceAll("\\[", "").replaceAll("\\]", "");
                    String[] splitedlist = spliter.split(",");
                    for (int i = 0; i < splitedlist.length-1; i += 2) {
                        dictionary.put(splitedlist[i].trim(),splitedlist[i+1]);
                    }
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });

        ((UHFApplication) getApplication()).addActivity(this);

        activity = this;

        // Storage Permissions
        ExcelUtils.verifyStoragePermissions(this);

        fordisplay_page1 = new ArrayList<String>(Arrays.asList(""));
        tobepopulater_page1 = new MyBasicArrayAdapter(this.getApplicationContext(),fordisplay_page1);
        tobepopulater_page1.clear();

        tobedisplayed_firstpage_list = (ListView) findViewById(R.id.listView_firstap);
        tobedisplayed_firstpage_list.setAdapter(tobepopulater_page1);


        linearmain = (LinearLayout) findViewById(R.id.main_linearlayout_hide);
        next = (Button) findViewById(R.id.checkbuttonn);
        Logo1 = (TextView) findViewById(R.id.logo1);
        Logo2 = (TextView) findViewById(R.id.logo2);
        mcount = (TextView) findViewById(R.id.count);

        linearmain.setVisibility(View.VISIBLE);

        next.setOnClickListener(new OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                        Intent intent;
                                        intent = new Intent().setClass(MainActivity.this, new_ERP_1.class);
                                        intent.putExtra("key", "start");

                                        startActivity(intent);

                                    }
                                });

        mRefreshButton = (TextView) findViewById(R.id.refresh);

        mRefreshButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                //clear the list
                test1 = null;
                try {
                    client.subscribe("first_page",0);
                    client.publish("itemlist", "anyythig".getBytes(), 0, false);
                } catch (MqttException e) {
                    e.printStackTrace();
                }
                fordisplay_page1.clear();
                mcount.setText("scanned: 0 ");
                tobepopulater_page1.notifyDataSetChanged();
                if (cur_item == MENUITEM.ITEM1) {
                    if (0 == currIndex) {
                        ((PageInventoryReal) findViewById(R.id.view_PageInventoryReal)).refresh();
                    } else {
                        ((PageTagAccess) findViewById(R.id.view_PageTagAccess)).refresh();
                    }
                } else if (cur_item == MENUITEM.ITEM2) {
                    if (0 == currIndex) {
                        ((PageInventoryReal6B) findViewById(R.id.view_PageInventoryReal6B)).refresh();
                    } else {
                        ((PageTag6BAccess) findViewById(R.id.view_PageTag6BAccess)).refresh();
                    }
                }
                next.setTextColor(Color.parseColor("#0BBBF7"));
            }
        });

        popupMenu = new PopupMenu(this);

        iv_menu = (ImageView) findViewById(R.id.iv_menu);
        iv_menu.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub

                popupMenu.showLocation(R.id.iv_menu);
                popupMenu.setOnItemClickListener(new OnItemClickListener() {

                    @Override
                    public void onClick(MENUITEM item, String str) {
                        if (item == MENUITEM.ITEM1) {

                            InitViewPager(MENUITEM.ITEM1);
                            mPager.setVisibility(View.INVISIBLE);
                            title[0].setVisibility(View.GONE);
                            title[1].setVisibility(View.GONE);
                            linearmain.setVisibility(View.VISIBLE);
                            Logo1.setVisibility(View.VISIBLE);
                            Logo2.setVisibility(View.VISIBLE);

                        } else if (item == MENUITEM.ITEM2) {
                            InitViewPager(MENUITEM.ITEM2);
                            linearmain.setVisibility(View.GONE);
                            Logo1.setVisibility(View.GONE);
                            Logo2.setVisibility(View.GONE);
                            mPager.setVisibility(View.VISIBLE);
                            title[0].setVisibility(View.VISIBLE);
                            title[1].setVisibility(View.VISIBLE);
                        } else if (item == MENUITEM.ITEM3) {
                            Intent intent;
                            intent = new Intent().setClass(MainActivity.this, SettingActivity.class);
                            startActivity(intent);
                        } else if (item == MENUITEM.ITEM4) {
                            askForOut();
                        } else if (item == MENUITEM.ITEM6) {
                            Intent intent;
                            intent = new Intent().setClass(MainActivity.this, new_ERP_1.class);
                            startActivity(intent);

                        }  /** else if (item == MENUITEM.ITEM7) {
                            Intent intent;
                            intent = new Intent().setClass(MainActivity.this, ERPList.class);
                            startActivity(intent);

                        } **/else if (item == MENUITEM.ITEM5) {
                            if (str.equals("English")) {
                                PreferenceUtil.commitString("language", "en");
                            } else if (str.equals("中文")) {
                                PreferenceUtil.commitString("language", "zh");
                            }
                            Intent intent = new Intent(MainActivity.this, MainActivity.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            MainActivity.this.startActivity(intent);

                        } else if (item == MENUITEM.ITEM_add1) {
                            saveExcel();
                        } else if (item == MENUITEM.ITEM8) {
                            mPager.setVisibility(View.VISIBLE);
                            title[0].setVisibility(View.VISIBLE);
                            title[1].setVisibility(View.VISIBLE);
                            linearmain.setVisibility(View.INVISIBLE);
                            Logo1.setVisibility(View.GONE);
                            Logo2.setVisibility(View.GONE);
                            item = MENUITEM.ITEM1;
                            InitViewPager(MENUITEM.ITEM1);

                        }
                    }
                });
            }
        });

        InitTextView();
        InitViewPager(MENUITEM.ITEM1);
        mPager.setVisibility(View.INVISIBLE);
        title[0].setVisibility(View.GONE);
        title[1].setVisibility(View.GONE);
        linearmain.setVisibility(View.VISIBLE);



        try {
            mReaderHelper = ReaderHelper.getDefaultHelper();
            mReader = mReaderHelper.getReader();
        } catch (Exception e) {
            return;
        }

        m_curReaderSetting = mReaderHelper.getCurReaderSetting();
        m_curInventoryBuffer = mReaderHelper.getCurInventoryBuffer();
        m_curOperateTagBuffer = mReaderHelper.getCurOperateTagBuffer();
        m_curOperateTagISO18000Buffer = mReaderHelper.getCurOperateTagISO18000Buffer();

        lbm = LocalBroadcastManager.getInstance(this);

        IntentFilter itent = new IntentFilter();
        itent.addAction(ReaderHelper.BROADCAST_REFRESH_FAST_SWITCH);
        itent.addAction(ReaderHelper.BROADCAST_REFRESH_INVENTORY);
        itent.addAction(ReaderHelper.BROADCAST_REFRESH_INVENTORY_REAL);
        itent.addAction(ReaderHelper.BROADCAST_REFRESH_ISO18000_6B);
        itent.addAction(ReaderHelper.BROADCAST_REFRESH_OPERATE_TAG);
        itent.addAction(ReaderHelper.BROADCAST_REFRESH_READER_SETTING);
        itent.addAction(ReaderHelper.BROADCAST_WRITE_LOG);
        itent.addAction(ReaderHelper.BROADCAST_WRITE_DATA);

        lbm.registerReceiver(mRecv, itent);


        InventoryBuffer test = m_curInventoryBuffer;
        //List<InventoryBuffer.InventoryTagMap> test = m_curInventoryBuffer.lsTagList;
        Map<String, Integer> test2 = test.dtIndexMap;
        test1 = test2.keySet().toString();

        // populate list if test1 is not empty
        if (test1 != null) {
            if (!test1.equals("")) {
                if (!test1.equals("[]")) {
                    Log.e("MainAtes1",test1);
            String testtest = test1;
            testtest = testtest.replaceAll("[\\[\\]\\\"]", "");
            String[] openlist = testtest.split(",");

            fordisplay_page1.clear();
            if (fordisplay_page1.size() != openlist.length + 1) {
                for (int i = 0; i < openlist.length; i++) {
                    fordisplay_page1.add(openlist[i]);
                }
            }
            mcount.setText("scanned: " + openlist.length);
            tobepopulater_page1.notifyDataSetChanged();

                        next.setTextColor(Color.GREEN);
                    }
                }

        }






        
    }

    private final BroadcastReceiver mRecv = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(ReaderHelper.BROADCAST_REFRESH_FAST_SWITCH)) {

            } else if (intent.getAction().equals(ReaderHelper.BROADCAST_REFRESH_INVENTORY)) {

            } else if (intent.getAction().equals(ReaderHelper.BROADCAST_REFRESH_INVENTORY_REAL)) {

            } else if (intent.getAction().equals(ReaderHelper.BROADCAST_REFRESH_ISO18000_6B)) {

            } else if (intent.getAction().equals(ReaderHelper.BROADCAST_REFRESH_OPERATE_TAG)) {

            } else if (intent.getAction().equals(ReaderHelper.BROADCAST_REFRESH_READER_SETTING)) {
                byte btCmd = intent.getByteExtra("cmd", (byte) 0x00);
            } else if (intent.getAction().equals(ReaderHelper.BROADCAST_WRITE_LOG)) {
            } else if (intent.getAction().equals(ReaderHelper.BROADCAST_WRITE_DATA) && PreferenceUtil.getBoolean(MonitorActivity.mIsChecked, false) && !mIsMonitorOpen) {
                ((UHFApplication) getApplication()).writeMonitor((String) intent.getStringExtra("log"), intent.getIntExtra("type", ERROR.SUCCESS));
            }
        }
    };

    private void InitTextView() {
        title[0] = (TextView) findViewById(R.id.tab_index1);
        title[1] = (TextView) findViewById(R.id.tab_index2);

        title[0].setOnClickListener(new MyOnClickListener(0));
        title[1].setOnClickListener(new MyOnClickListener(1));
    }

    private void InitViewPager(MENUITEM item) {
        cur_item = item;
        mPager = (ViewPager) findViewById(R.id.vPager);
        listViews = new ArrayList<>();
        LayoutInflater mInflater = getLayoutInflater();
        if (item == MENUITEM.ITEM1) {
            //listViews.add(mInflater.inflate(R.layout.substitute_mainpage, null));
            listViews.add(mInflater.inflate(R.layout.lay1, null));
            listViews.add(mInflater.inflate(R.layout.lay2, null));

        } else if (item == MENUITEM.ITEM2) {
            listViews.add(mInflater.inflate(R.layout.lay3, null));
            listViews.add(mInflater.inflate(R.layout.lay4, null));
        }
        mPager.setAdapter(new MyPagerAdapter(listViews));
        mPager.setCurrentItem(0);
        mPager.setOnPageChangeListener(new MyOnPageChangeListener());
        currIndex = 0;
        title[1].setBackgroundResource(R.drawable.btn_select_background_select_left_down);
        title[0].setBackgroundResource(R.drawable.btn_select_background_select_right);
        title[1].setTextColor(Color.rgb(0x00, 0xBB, 0xF7));
        title[0].setTextColor(Color.rgb(0xFF, 0xFF, 0xFF));
    }

    public class MyPagerAdapter extends PagerAdapter {
        public List<View> mListViews;

        public MyPagerAdapter(List<View> mListViews) {
            this.mListViews = mListViews;
        }

        @Override
        public void destroyItem(View arg0, int arg1, Object arg2) {
            ((ViewPager) arg0).removeView(mListViews.get(arg1));
        }

        @Override
        public void finishUpdate(View arg0) {
        }

        @Override
        public int getCount() {
            return mListViews.size();
        }

        @Override
        public Object instantiateItem(View arg0, int arg1) {
            ((ViewPager) arg0).addView(mListViews.get(arg1), 0);
            return mListViews.get(arg1);
        }

        @Override
        public boolean isViewFromObject(View arg0, Object arg1) {
            return arg0 == (arg1);
        }

        @Override
        public void restoreState(Parcelable arg0, ClassLoader arg1) {
        }

        @Override
        public Parcelable saveState() {
            return null;
        }

        @Override
        public void startUpdate(View arg0) {
        }
    }

    public class MyOnClickListener implements OnClickListener {
        private int index = 0;

        public MyOnClickListener(int i) {
            index = i;
        }

        @Override
        public void onClick(View v) {
            mPager.setCurrentItem(index);
        }
    }

    public class MyOnPageChangeListener implements OnPageChangeListener {

        @Override
        public void onPageSelected(int arg0) {
            currIndex = arg0;
            if (0 == currIndex) {
                title[1].setBackgroundResource(R.drawable.btn_select_background_select_left_down);
                title[0].setBackgroundResource(R.drawable.btn_select_background_select_right);
                mSaveType = 0;
            } else {
                title[1].setBackgroundResource(R.drawable.btn_select_background_select_left);
                title[0].setBackgroundResource(R.drawable.btn_select_background_select_right_down);
                mSaveType = 1;
            }

            title[1 - currIndex].setTextColor(Color.rgb(0x00, 0xBB, 0xF7));
            title[currIndex].setTextColor(Color.rgb(0xFF, 0xFF, 0xFF));
        }

        @Override
        public void onPageScrolled(int arg0, float arg1, int arg2) {
        }

        @Override
        public void onPageScrollStateChanged(int arg0) {
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_BACK:
                askForOut();
                return true;
            case KeyEvent.KEYCODE_MENU:
                break;

            case KeyEvent.KEYCODE_F4: {
                if (cur_item == MENUITEM.ITEM1) {
                    if (0 == currIndex) {
                        if (!mKeyF4Pressing) {
                            mKeyF4Pressing = true;
                            ((PageInventoryReal) findViewById(R.id.view_PageInventoryReal)).mKeyF4Pressing = true;
                            ((PageInventoryReal) findViewById(R.id.view_PageInventoryReal)).startStopFF();
                        }
                    }
                } else if (cur_item == MENUITEM.ITEM2) {
                    if (0 == currIndex) {
                        if (!mKeyF4Pressing) {
                            mKeyF4Pressing = true;
                            ((PageInventoryReal6B) findViewById(R.id.view_PageInventoryReal6B)).mKeyF4Pressing = true;
                            ((PageInventoryReal6B) findViewById(R.id.view_PageInventoryReal6B)).startStopFF();
                        }
                    }
                }

            }

            break;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {


        InventoryBuffer test = m_curInventoryBuffer;
        //List<InventoryBuffer.InventoryTagMap> test = m_curInventoryBuffer.lsTagList;
        Map<String, Integer> test2 = test.dtIndexMap;
        test1 = test2.keySet().toString();
        //populate list
        Log.e("MainAtest",test1);

        if (test1 != null) {
            if (!test1.equals("")) {
                if (!test1.equals("[]")) {
                    Log.e("MainAtest2",test1);

        String testtest = test1;
        testtest = testtest.replaceAll("[\\[\\]\\\"]", "");
        String[] openlist = testtest.split(",");

        fordisplay_page1.clear();
        if (fordisplay_page1.size() != openlist.length + 1) {
            for (int i = 0; i < openlist.length; i++) {
                fordisplay_page1.add(openlist[i]);
            }
        }
                    mcount.setText("scanned: " + openlist.length);
        tobepopulater_page1.notifyDataSetChanged();

                    next.setTextColor(Color.parseColor("#018524"));
                }
            }
        }

        if (keyCode == KeyEvent.KEYCODE_MENU) {
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_F4) {

            if (cur_item == MENUITEM.ITEM1) {
                if (0 == currIndex) {
                    mKeyF4Pressing = false;
                    ((PageInventoryReal) findViewById(R.id.view_PageInventoryReal)).mKeyF4Pressing = false;
                    ((PageInventoryReal) findViewById(R.id.view_PageInventoryReal)).startStopFF();
                }
            } else if (cur_item == MENUITEM.ITEM2) {
                if (0 == currIndex) {
                    mKeyF4Pressing = false;
                    ((PageInventoryReal6B) findViewById(R.id.view_PageInventoryReal6B)).mKeyF4Pressing = false;
                    ((PageInventoryReal6B) findViewById(R.id.view_PageInventoryReal6B)).startStopFF();
                }
            }
        }
        return super.onKeyUp(keyCode, event);
    }

    private void askForOut() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(getString(R.string.alert_diag_title)).
                setMessage(getString(R.string.are_you_sure_to_exit)).
                setPositiveButton(getString(R.string.ok),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                PreferenceUtil.commitInt(MainActivity.REGION_TYPE, m_curReaderSetting.btRegion);
                                PreferenceUtil.commitInt(MainActivity.FREQUENCY_INTERVAL, m_curReaderSetting.btUserDefineFrequencyInterval);
                                PreferenceUtil.commitInt(MainActivity.START_FREQUENCY, m_curReaderSetting.nUserDefineStartFrequency);
                                //close the module
                                ModuleManager.newInstance().setUHFStatus(false);
                                getApplication().onTerminate();
                            }
                        }).setNegativeButton(getString(R.string.cancel),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).setCancelable(false).show();
    }

    /**
     * Save the tags as excel file;
     */
    private void saveExcel() {
        CustomedDialog customedDialog = new CustomedDialog(this, R.layout.excel_save_dialog);
        customedDialog.setTags(m_curInventoryBuffer.lsTagList);
        customedDialog.setOperationTags(m_curOperateTagBuffer.lsTagList);
        customedDialog.getDialog();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }


    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        if (lbm != null)
            lbm.unregisterReceiver(mRecv);
        // Chong 23/8/2022
        //BeeperUtils.release();
    }

    private static void IFAILED(){
        String clientId = MqttClient.generateClientId();

        final MqttAndroidClient client = new MqttAndroidClient
                (activity.getApplicationContext(), myIP, clientId);

        IMqttToken token = null;
        {
            try {
                token = client.connect();
                Log.e("mainA", "to the client");

            } catch (MqttException e) {
                e.printStackTrace();
            }
        } //connect
        token.setActionCallback(new IMqttActionListener() {
            @Override
            public void onSuccess(IMqttToken asyncActionToken) {
                Log.e("MAINpage2", "connected");
                try {
                    client.subscribe("first_page",0);
                    client.publish("itemlist", "anyythig".getBytes(), 0, false);
                }catch (MqttException e){
                    e.printStackTrace();
                }
            }
            @Override
            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                Log.e("MAINdoisconnected", "disconnected");
            }
        });

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                Log.e("MAINAplz","RC");
                IFAILED();
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception
            {
                dictionary.clear();
                Log.e("mainactivy", topic);
                String msg_2 = new String(message.getPayload()) ;
                Log.e("mainacityvy1st page", (msg_2));
                if (msg_2 != null) {
                    String spliter = msg_2;
                    spliter = spliter.replaceAll("[{}]", "");
                    spliter = spliter.replaceAll("\"", "");System.out.println(spliter);
                    spliter = spliter.replaceAll("\\[", "").replaceAll("\\]", "");
                    String[] splitedlist = spliter.split(",");
                    for (int i = 0; i < splitedlist.length-1; i += 2) {
                        dictionary.put(splitedlist[i].trim(),splitedlist[i+1]);
                    }
                }
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });
    }
}
